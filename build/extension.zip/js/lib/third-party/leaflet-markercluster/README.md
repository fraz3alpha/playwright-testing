
Project website: https://github.com/Leaflet/Leaflet.markercluster

Downloaded from: https://github.com/Leaflet/Leaflet.markercluster/releases

2018-07-11: Version 1.3.0 - https://github.com/Leaflet/Leaflet.markercluster/archive/v1.3.0.zip
