
Project website: https://github.com/jquery/jquery

Downloaded from: https://github.com/jquery/jquery/releases

2022-05-25: Version 3.6.0 - https://github.com/jquery/jquery/archive/3.6.0.zip

Previous versions:

2018-01-10: Version 3.3.1 - https://github.com/jquery/jquery/archive/3.3.1.zip
