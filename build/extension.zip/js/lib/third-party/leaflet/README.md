
Project website: https://github.com/Leaflet/Leaflet

Downloaded from: https://github.com/Leaflet/Leaflet/releases

2018-07-11: Version 1.3.1 - https://github.com/Leaflet/Leaflet/archive/v1.3.1.zip
