
Project website: https://github.com/mozilla/webextension-polyfill

Downloaded from: https://github.com/mozilla/webextension-polyfill/blob/76eeeaccc9faaf6403addaf1ee829a8b0b238957/src/browser-polyfill.js

2018-05-14: git commit 76eeeac - https://github.com/mozilla/webextension-polyfill/tree/76eeeaccc9faaf6403addaf1ee829a8b0b238957

N.B. We should probably move up to the official release v0.3.0 - https://github.com/mozilla/webextension-polyfill/releases/tag/0.3.0
