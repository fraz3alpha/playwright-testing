
Project website: https://github.com/sashakavun/leaflet-canvasicon

Downloaded from: https://github.com/sashakavun/leaflet-canvasicon/releases.

2018-07-11: Version 0.1.4 - https://github.com/sashakavun/leaflet-canvasicon/archive/0.1.4.zip
