
Project website: https://github.com/Leaflet/Leaflet.fullscreen

Downloaded from: https://github.com/Leaflet/Leaflet.fullscreen/releases

2018-07-11: Version 1.0.2 - https://github.com/Leaflet/Leaflet.fullscreen/archive/v1.0.2.zip
