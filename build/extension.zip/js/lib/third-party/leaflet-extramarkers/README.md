
Project website: https://github.com/coryasilva/Leaflet.ExtraMarkers

Downloaded from: https://github.com/coryasilva/Leaflet.ExtraMarkers/releases

2018-07-11: Version 1.0.5 - https://github.com/coryasilva/Leaflet.ExtraMarkers/archive/v1.0.5.zip
