
Project website: https://github.com/d3/d3-voronoi

Downloaded from: https://github.com/d3/d3-voronoi/releases

2019-12-24: Version 1.1.2 - https://github.com/d3/d3-voronoi/releases/download/v1.1.2/d3-voronoi.zip
